#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <locale.h>
#include <fstream>
#include <string>
#include <conio.h>
#include "gconio.h"
#include <limits>

using namespace std;



int MAX_COLUNAS = 90; // verificar o total de colunas na sua tela
int MAX_LINHAS = 25;  // verificar o total de linhas na sua tela
int COR_FUNDO = LIGHTBLUE;
int COR_LETRA = WHITE;

struct Jogadores {
    char P1 = 'X';
    char P2 = 'O';
};

void tela_azul_fundo(int COR_FUNDO, int COR_LETRA, int MAX_LINHAS);
void desenhaTabuleiro(Jogadores jogadores, char posicoes[8][3]);
bool verificarMoinho(char jogador, char posicoes[8][3]);
void capturarPeca(char jogador, char posicoes[8][3], char adversario, Jogadores jogadores);
void moverpeca(char jogador, char posicoes[8][3], Jogadores jogadores, int& linhaOrigem, int& colunaOrigem, int& posicaoinvalida);
int ContadorDepecas(char posicoes[8][3], char escolha);
bool PermitirMover(int LinhaOrigem, int ColunaOrigem, int LinhaDestino, int ColunaDestino);
void limparCin();
void TelaInicial();
void Tela_liga();
void animacao_tela_inicial_trilha();
void exibir_carregamento();
void encerrado();
void menu_final(bool& escolha_valida);
void menu_final1();
int contPecaX = 3;
int contPecaO = 3;


int main() {
    setlocale (LC_ALL, "Portuguese");
    Jogadores jogadores;

    // Inicializando o tabuleiro
    /*char posicoes[8][3] = {
        {' ', ' ', ' '},
        {' ', ' ', ' '},
        {' ', ' ', ' '},
        {' ', ' ', ' '},
        {' ', ' ', ' '},
        {' ', ' ', ' '},
        {' ', ' ', ' '},
        {' ', ' ', ' '}
    };*/

    int linha, coluna, countjogador = 0,maxpecas=0;
    char escolha_X_O;
    char Ligar_o_sistema;
    tela_azul_fundo(LIGHTBLUE,WHITE,MAX_LINHAS);
    Tela_liga();
    gotoxy(12,12);printf("Ligar o sistema[S] :");
    gotoxy(12,13);printf("->");
    scanf("%s", &Ligar_o_sistema);
    int a=1;
    int b=0;
    bool escolha_valida;

    if (Ligar_o_sistema == 's' || Ligar_o_sistema == 'S' )
        {
            clrscr();
            TelaInicial();
            clrscr();
            tela_azul_fundo(LIGHTBLUE, WHITE, MAX_LINHAS);
            animacao_tela_inicial_trilha();
            exibir_carregamento();
            int escolha_contador = 0;
            do{
                char posicoes[8][3] = {
                    {' ', ' ', ' '},
                    {' ', ' ', ' '},
                    {' ', ' ', ' '},
                    {' ', ' ', ' '},
                    {' ', ' ', ' '},
                    {' ', ' ', ' '},
                    {' ', ' ', ' '},
                    {' ', ' ', ' '}
                };
                contPecaX = 3; contPecaO = 3; countjogador = 0; maxpecas=0;
                do {
                    clrscr();
                    tela_azul_fundo(LIGHTBLUE, WHITE, MAX_LINHAS);
                    desenhaTabuleiro(jogadores, posicoes);
                    escolha_contador++;

                    if (escolha_contador % 2 == 1){
                        escolha_X_O = 'X';
                    }
                    else{
                        escolha_X_O = 'O';
                    }

                    gotoxy(1, 10); cout << "Vez do jogador "<<"\n";
                    gotoxy(1, 11); cout << "---> " << escolha_X_O;
                    //cin >> escolha_X_O;

                    //controlar a ordem de jogadas
                    if(tolower(escolha_X_O)=='x'){
                        if(countjogador%2==0){
                        }
                        else{
                            textbackground(WHITE);textcolor(RED);gotoxy(1,20);cout << "Escolha invalida! Tente novamente.\n";
                            continue;
                        }
                    }
                    else if(tolower(escolha_X_O)=='o'){
                        if(countjogador%2!=0){
                        }
                        else{
                            textbackground(WHITE);textcolor(RED);gotoxy(1,20);cout << "Escolha invalida! Tente novamente.\n";
                            continue;
                        }
                    }
                    else{
                        continue;
                    }

                    gotoxy(1, 12); cout << "Digite a linha (1-8): ";
                    cin >> linha;

                    if(!(cin)){
                        limparCin();
                        textbackground(WHITE);
                        textcolor(RED);
                        gotoxy(1, 20);
                        cout << "Entrada inv�lida! Por favor, insira um n�mero entre 1 e 8.\n";
                        system("pause>NULL");
                        continue;
                    }

                    gotoxy(1, 13); cout << "Digite a coluna (1-3): ";
                    cin >> coluna;

                    if(!(cin)){
                        limparCin();
                        textbackground(WHITE);
                        textcolor(RED);
                        gotoxy(1, 20);
                        cout << "Entrada inv�lida! Por favor, insira um n�mero entre 1 e 8.\n";
                        system("pause>NULL");
                        continue;}

                    linha--;
                    coluna--;

                    if (escolha_X_O == 'X' || escolha_X_O == 'x') {
                        if (linha >= 0 && linha < 8 && coluna >= 0 && coluna < 3 &&
                            posicoes[linha][coluna] != jogadores.P1 &&
                            posicoes[linha][coluna] != jogadores.P2){
                            posicoes[linha][coluna] = jogadores.P1; // Jogador 1 com X
                            system("cls");
                            tela_azul_fundo(LIGHTBLUE, WHITE, MAX_LINHAS);
                            desenhaTabuleiro(jogadores, posicoes);
                            countjogador+=1;
                                if (verificarMoinho(jogadores.P1, posicoes)) {
                                    capturarPeca(jogadores.P1, posicoes, jogadores.P2, jogadores);
                                    contPecaO-=1;

                                }
                            } else {
                                textbackground(WHITE);textcolor(RED);gotoxy(1,20);cout << "Posicao invalida! Tente novamente.\n";
                                system("pause>NULL");//pausa at� que uma tecla seja digitada
                                clrscr();
                                tela_azul_fundo(LIGHTBLUE, WHITE, MAX_LINHAS);
                                desenhaTabuleiro(jogadores, posicoes);
                            }
                    } else if (escolha_X_O == 'O' || escolha_X_O == 'o') {
                        if (linha >= 0 && linha < 8 && coluna >= 0 && coluna < 3 &&
                            posicoes[linha][coluna] != jogadores.P1 &&
                            posicoes[linha][coluna] != jogadores.P2) {
                            posicoes[linha][coluna] = jogadores.P2; // Jogador 2 com O
                            system("cls");
                            tela_azul_fundo(LIGHTBLUE, WHITE, MAX_LINHAS);
                            desenhaTabuleiro(jogadores, posicoes);
                            countjogador+=1;
                            maxpecas+=1;
                                if (verificarMoinho(jogadores.P2, posicoes)) {
                                    capturarPeca(jogadores.P2, posicoes, jogadores.P1, jogadores);
                                    contPecaX-=1;

                                }
                        } else {
                            textbackground(WHITE);textcolor(RED);gotoxy(1,20);cout << "Posicao invalida! Tente novamente.\n";
                             system("pause>NULL");//pausa at� que uma tecla seja digitada
                             clrscr();
                             tela_azul_fundo(LIGHTBLUE, WHITE, MAX_LINHAS);
                             desenhaTabuleiro(jogadores, posicoes);
                            }
                    } else {
                         textbackground(WHITE);textcolor(RED);gotoxy(1,20);cout << "Escolha invalida! Tente novamente.\n";
                        system("pause>NULL");//pausa at� que uma tecla seja digitada
                        clrscr();
                        tela_azul_fundo(LIGHTBLUE, WHITE, MAX_LINHAS);
                        desenhaTabuleiro(jogadores, posicoes);
                        }
            } while (maxpecas!=3);

            countjogador=0;
            int JogadorO =0, JogadorX=0, posicaoinvalida =0;
            do{
                JogadorO=ContadorDepecas(posicoes,'O'); JogadorX = ContadorDepecas(posicoes,'X');
                if(JogadorO < 3 || JogadorX<3){
                    break;
                }
                clrscr();
                tela_azul_fundo(LIGHTBLUE, WHITE, MAX_LINHAS);
                desenhaTabuleiro(jogadores, posicoes);
                escolha_contador++;
                if (escolha_contador % 2 == 1){
                    escolha_X_O = 'X';
                }
                else{
                    escolha_X_O = 'O';
                }
                if(tolower(escolha_X_O)=='x' && countjogador%2==0){
                    //Jogador 1
                    moverpeca(escolha_X_O, posicoes, jogadores,linha, coluna, posicaoinvalida);
                     if(posicaoinvalida >=2){
                        textbackground(WHITE);textcolor(RED);gotoxy(1,20);cout << "JOGADOR O GANHOU";
                        contPecaX = 0;
                        menu_final(escolha_valida);
                       // break;

                     }
                    clrscr();
                    tela_azul_fundo(LIGHTBLUE, WHITE, MAX_LINHAS);
                    desenhaTabuleiro(jogadores, posicoes);

                    if (linha >= 0 && linha < 8 && coluna >= 0 && coluna < 3 &&
                        posicoes[linha][coluna] != jogadores.P1 &&
                        posicoes[linha][coluna] != jogadores.P2){

                            if (verificarMoinho(jogadores.P1,posicoes)) {
                            capturarPeca(jogadores.P1, posicoes, jogadores.P2, jogadores);
                            contPecaO-=1;
                            }
                    }
                    else {
                        textbackground(WHITE);textcolor(RED);gotoxy(1,20);cout << "Posicao invalida! Tente novamente.\n";
                        system("pause>NULL");
                        continue;
                    }
                    countjogador++;
                }
                else if(tolower(escolha_X_O)=='o' && countjogador%2!=0){
                    //Jogador 2
                     moverpeca(escolha_X_O, posicoes, jogadores, linha, coluna, posicaoinvalida);
                     if(posicaoinvalida >=2){
                        textbackground(WHITE);textcolor(RED);gotoxy(1,20);cout << "JOGADOR X GANHOU";
                        contPecaO = 0;
                        menu_final(escolha_valida);
                        //break;
                     }
                     clrscr();
                     tela_azul_fundo(LIGHTBLUE, WHITE, MAX_LINHAS);
                     desenhaTabuleiro(jogadores, posicoes);

                    if (linha >= 0 && linha < 8 && coluna >= 0 && coluna < 3 &&
                        posicoes[linha][coluna] != jogadores.P1 &&
                        posicoes[linha][coluna] != jogadores.P2) {
                            // Jogador 2 com O
                        if (verificarMoinho(jogadores.P2, posicoes)) {
                            capturarPeca(jogadores.P2, posicoes, jogadores.P1, jogadores);
                            contPecaX-=1;
                        }
                    } else {
                        textbackground(WHITE);textcolor(RED);gotoxy(1,20);cout << "Posicao invalida! Tente novamente.\n";
                         system("pause>NULL");//pausa at� que uma tecla seja digitada
                         continue;
                    }
                    countjogador++;
                }
                else{
                     textbackground(WHITE);textcolor(RED);gotoxy(1,20);cout << "Escolha invalida! Tente novamente.\n";
                    continue;
                }
            }while(true);

            menu_final(escolha_valida);
        }while(escolha_valida);
    }

    return 0;


}


void desenhaTabuleiro(Jogadores jogadores, char posicoes[8][3]) {

    gotoxy(1,5);cout << "   Menu:" << "\n";
    gotoxy(1,6);cout << "Jogador 1 [" << jogadores.P1 << "]" << " Pe�as restantes: "<< contPecaX << "\n";
    gotoxy(1,7);cout << "Jogador 2 [" << jogadores.P2 << "]" << " Pe�as restantes: "<< contPecaO << "\n";

    gotoxy(52,2);printf(" Jogo Trilha Tabuleiro");
    gotoxy(40,3);printf(" %c---------------------%c---------------------%c\n", posicoes[0][0], posicoes[0][1], posicoes[0][2]);
    gotoxy(40,4);printf(" |                     |                     |\n");
    gotoxy(40,5);printf(" |                     |                     |\n");
    gotoxy(40,6);printf(" |       %c-------------%c-------------%c       |\n", posicoes[1][0], posicoes[1][1], posicoes[1][2]);
    gotoxy(40,7);printf(" |       |             |             |       |\n");
    gotoxy(40,8);printf(" |       |             |             |       |\n");
    gotoxy(40,9);printf(" |       |      %c------%c------%c      |       |\n", posicoes[2][0], posicoes[2][1], posicoes[2][2]);
    gotoxy(40,10);printf(" |       |      |             |      |       |\n");
    gotoxy(40,11);printf(" |       |      |             |      |       |\n");
    gotoxy(40,12);printf(" %c-------%c------%c             %c------%c-------%c\n", posicoes[3][0], posicoes[3][1], posicoes[3][2], posicoes[5][0], posicoes[5][1], posicoes[5][2]);
    gotoxy(40,13);printf(" |       |      |             |      |       |\n");
    gotoxy(40,14);printf(" |       |      |             |      |       |\n");
    gotoxy(40,15);printf(" |       |      %c------%c------%c      |       |\n", posicoes[4][0], posicoes[4][1], posicoes[4][2]);
    gotoxy(40,16);printf(" |       |             |             |       |\n");
    gotoxy(40,17);printf(" |       |             |             |       |\n");
    gotoxy(40,18);printf(" |       %c-------------%c-------------%c       |\n", posicoes[6][0], posicoes[6][1], posicoes[6][2]);
    gotoxy(40,19);printf(" |                     |                     |\n");
    gotoxy(40,20);printf(" |                     |                     |\n");
    gotoxy(40,21);printf(" %c---------------------%c---------------------%c\n", posicoes[7][0], posicoes[7][1], posicoes[7][2]);
    gotoxy(92, 4);printf(" MAPA POSI��ES TABULEIRO");
    gotoxy(92, 6);printf("11----------12----------13");
    gotoxy(92, 7);printf("|           |           |");
    gotoxy(92, 8);printf("|   21------22------23  |");
    gotoxy(92, 9);printf("|   |       |       |   |");
    gotoxy(92,10);printf("|   |   31--32--33  |   |");
    gotoxy(92,11);printf("|   |   |       |   |   |");
    gotoxy(92,12);printf("41--42--43      61--62--63");
    gotoxy(92,13);printf("|   |   |       |   |   |");
    gotoxy(92,14);printf("|   |   51--52--53  |   |");
    gotoxy(92,15);printf("|   |       |       |   |");
    gotoxy(92,16);printf("|   71------72------73  |");
    gotoxy(92,17);printf("|           |           |");
    gotoxy(92,18);printf("81----------82----------83");



}


void tela_azul_fundo(int COR_FUNDO, int COR_LETRA, int MAX_LINHAS){
    textbackground(COR_FUNDO);
    textcolor(COR_LETRA);

    for(int linha=0;linha<MAX_LINHAS;linha++){
        for(int coluna=0; coluna<MAX_COLUNAS;coluna++)
            printf(" ");
        printf("\n");
    }

    gotoxy(0,0);
    printf("-",201);
    for(int coluna=1;coluna<MAX_COLUNAS-1;coluna++)
        printf("-",205);

    printf("%c\n",187);
    for(int linha=1;linha<MAX_LINHAS-1;linha++){
        gotoxy(0,linha);printf("|",186);
        gotoxy(MAX_COLUNAS-1,linha);printf("|",186);
    }

    printf("\n-",200);
    for(int coluna=1;coluna<MAX_COLUNAS-1;coluna++)
        printf("-",205);
    printf("-",188);
}

bool verificarMoinho(char jogador, char posicoes[8][3]){
    // Verifica moinhos nas linhas (horizontal)
    for (int i = 0; i < 8; i++) {
        if (posicoes[i][0] == jogador && posicoes[i][1] == jogador && posicoes[i][2] == jogador) {
            return true; // Encontrou moinho horizontal
        }
    }

    // Verifica moinhos nas colunas (vertical)

        if (posicoes[0][0] == jogador && posicoes[3][0] == jogador && posicoes[7][0] == jogador) {
            return true;
        }
        if (posicoes[0][1] == jogador && posicoes[1][1] == jogador && posicoes[2][1] == jogador) {
            return true;
        }
        if (posicoes[0][2] == jogador && posicoes[5][2] == jogador && posicoes[7][2] == jogador) {
            return true;
        }

        if (posicoes[1][0] == jogador && posicoes[3][1] == jogador && posicoes[6][0] == jogador) {
            return true;
        }

        if (posicoes[2][0] == jogador && posicoes[3][2] == jogador && posicoes[4][0] == jogador) {
            return true;
        }

        if (posicoes[4][1] == jogador && posicoes[6][1] == jogador && posicoes[7][1] == jogador) {
            return true;
        }
        if (posicoes[1][2] == jogador && posicoes[5][1] == jogador && posicoes[6][2] == jogador) {
            return true;
        }
        if (posicoes[2][2] == jogador && posicoes[5][0] == jogador && posicoes[4][2] == jogador) {
            return true;
        }

    // Nenhum moinho encontrado
    return false;
}

void capturarPeca(char jogador, char posicoes[8][3], char adversario, Jogadores jogadores) {
    int linha, coluna;
    bool capturaValida = false;

    do {
        gotoxy(1,19);cout << "Jogador [" << jogador << "] voce formou um Moinho!\n";
        gotoxy(1,20);cout << "Escolha a posicao da peca ["<<adversario<<"]:\n";
        gotoxy(1,22);cout << "Digite a linha (1-8): ";
        cin >> linha;
        gotoxy(1,23);cout << "Digite a coluna (1-3): ";
        cin >> coluna;

        linha--;
        coluna--;

        if (linha >= 0 && linha < 8 && coluna >= 0 && coluna < 3 && posicoes[linha][coluna] == adversario) {
            posicoes[linha][coluna] = ' ';
            gotoxy(1,24);cout << "Peca adversaria capturada na posicao [" << linha + 1 << "][" << coluna + 1 << "].\n";
            capturaValida = true;

            // Atualizar o tabuleiro ap�s a captura
            system("cls");
            tela_azul_fundo(LIGHTBLUE, WHITE, MAX_LINHAS);
            desenhaTabuleiro(jogadores, posicoes);

        } else {
            textbackground(WHITE);textcolor(RED);gotoxy(37,22);cout << "Posicao invalida! Selecione uma peca do adversario.";
            system("pause>NULL");//pausa at� que uma tecla seja digitada
            clrscr();
            tela_azul_fundo(LIGHTBLUE, WHITE, MAX_LINHAS);
            desenhaTabuleiro(jogadores, posicoes);


        }
    } while (!capturaValida);
}
void moverpeca(char jogador, char posicoes[8][3], Jogadores jogadores, int& linhaOrigem, int& colunaOrigem, int& posicaoinvalida){
        int linhaDestino, colunaDestino;
        do {
            clrscr();
            tela_azul_fundo(LIGHTBLUE, WHITE, MAX_LINHAS);
            desenhaTabuleiro(jogadores, posicoes);
            linhaOrigem=0;
            colunaOrigem=0;
            gotoxy(1, 15); cout << "Jogador [" << jogador << "] escolha a pe�a a mover: ";
            gotoxy(1, 17); cout << "Digite a linha da pe�a (1-8): ";
            cin >> linhaOrigem;

            if(!(cin)){
                limparCin();
                textbackground(WHITE);
                textcolor(RED);
                gotoxy(1, 20);
                cout << "Entrada inv�lida! Por favor, insira um n�mero entre 1 e 8.\n";
                system("pause>NULL");
                continue;}

            gotoxy(1, 18); cout << "Digite a coluna da pe�a (1-3): ";
            cin >> colunaOrigem;

            if(!(cin)){
                limparCin();
                textbackground(WHITE);
                textcolor(RED);
                gotoxy(1, 20);
                cout << "Entrada inv�lida! Por favor, insira um n�mero entre 1 e 8.\n";
                system("pause>NULL");
                continue;}

            linhaOrigem--;
            colunaOrigem--;
            int sinal = 0;
            // Verificar se a pe�a na posi��o de origem � do jogador
            if (linhaOrigem >= 0 && linhaOrigem < 8 && colunaOrigem >= 0 && colunaOrigem < 3 &&
            posicoes[linhaOrigem][colunaOrigem] == toupper(jogador)) {
                sinal = 1;
            }else {
                textbackground(WHITE); textcolor(RED); gotoxy(1, 22); cout << "Posi��o inv�lida! Escolha uma pe�a sua.";
                system("pause>NULL");
                clrscr();
                tela_azul_fundo(LIGHTBLUE, WHITE, MAX_LINHAS);
                desenhaTabuleiro(jogadores, posicoes);
            }
            if(sinal == 1){
                gotoxy(1, 19); cout << "Digite a linha de destino (1-8): ";
                cin >> linhaDestino;
                if(!(cin)){
                    limparCin();
                    textbackground(WHITE);
                    textcolor(RED);
                    gotoxy(1, 20);
                    cout << "Entrada inv�lida! Por favor, insira um n�mero entre 1 e 8.\n";
                    system("pause>NULL");
                    continue;}
                gotoxy(1, 20); cout << "Digite a coluna de destino (1-3): ";
                cin >> colunaDestino;
                if(!(cin)){
                    limparCin();
                    textbackground(WHITE);
                    textcolor(RED);
                    gotoxy(1, 20);
                    cout << "Entrada inv�lida! Por favor, insira um n�mero entre 1 e 8.\n";
                    system("pause>NULL");
                    continue;}

                linhaDestino--;
                colunaDestino--;

                if(PermitirMover(linhaOrigem,colunaOrigem,linhaDestino,colunaDestino)){
                    if (linhaDestino >= 0 && linhaDestino < 8 && colunaDestino >= 0 && colunaDestino < 3 &&
                    posicoes[linhaDestino][colunaDestino] != 'O' && posicoes[linhaDestino][colunaDestino] != 'X' ) {
                        break;
                    } else {
                        textbackground(WHITE); textcolor(RED); gotoxy(1, 25); cout << "Posi��o inv�lida! Escolha uma posi��o vazia.";
                        posicaoinvalida+=1;
                        if(posicaoinvalida >=2){
                            break;
                        }
                        system("pause>NULL");
                        clrscr();
                        tela_azul_fundo(LIGHTBLUE, WHITE, MAX_LINHAS);
                        desenhaTabuleiro(jogadores, posicoes);

                    }
                }
                else{
                    textbackground(WHITE); textcolor(RED); gotoxy(1, 25); cout << "Posi��o inv�lida! Escolha uma posi��o proxima.";
                    system("pause>NULL");
                    clrscr();
                    tela_azul_fundo(LIGHTBLUE, WHITE, MAX_LINHAS);
                    desenhaTabuleiro(jogadores, posicoes);
                }
            }
    } while (true);

        // Realizar o movimento: troca a pe�a de lugar
        posicoes[linhaDestino][colunaDestino] = jogador;
        posicoes[linhaOrigem][colunaOrigem] = ' ';
        system("cls");
        tela_azul_fundo(LIGHTBLUE, WHITE, MAX_LINHAS);
        desenhaTabuleiro(jogadores, posicoes);
}
 int ContadorDepecas(char posicoes[8][3], char escolha){
    int countPecas = 0;
    if(escolha=='X' || escolha == 'x'){
        for(int i = 0; i<8; i++){
            for(int j=0;j<3;j++){
                if(posicoes[i][j]=='X' || posicoes[i][j]=='x'){
                   countPecas++;
                }
            }
        }
    }
    else if (escolha == 'O' || escolha == 'o') {
        for(int i = 0; i<8; i++){
            for(int j=0; j<3; j++){
                if(posicoes[i][j]== 'O' || posicoes[i][j]=='o'){
                   countPecas++;
                }
            }
        }
    }
    return countPecas;
 }

 void TelaInicial(){

    setlocale(LC_ALL, "portuguese");
    char entrada;
    bool jogoIniciado = false;
    tela_azul_fundo(LIGHTBLUE, WHITE,MAX_LINHAS);

    gotoxy(36,1);cout<< "JOGO DA TRILHA" << endl;

    //abre arquivo
    FILE *arquivo = fopen("jogo_regras.txt", "r");
    char linhas[80]; //string para armazenar a linha do arquivo
    int i = 3;
    //percorre as linhas do arquivo e mostra na tela
    while(fgets(linhas, 80, arquivo) !=NULL){
        gotoxy(6, i);printf("%s", linhas);
        i++;
    }
    fclose(arquivo); //fecha arquivo

    gotoxy(30,15);cout<<"Deseja iniciar o jogo?(S-N)";
    gotoxy(42,16);cin>>entrada;
    if(tolower(entrada)=='s' ){
        gotoxy(30,18);cout<<"Jogo ser� aberto....";
        Sleep(500);
        jogoIniciado = true;
    }
    else{
        gotoxy(30,18);cout<<"Jogo n�o ser� aberto";
    }

    if (!jogoIniciado) {
        exit(0);
    }

 }

 bool PermitirMover(int LinhaOrigem, int ColunaOrigem, int LinhaDestino, int ColunaDestino){
     bool permissao = false;

    //Linha 0
    if(LinhaOrigem == 0 && ColunaOrigem == 0){
        if(LinhaDestino == 0 && ColunaDestino == 1 || LinhaDestino == 3 && ColunaDestino == 0){
            permissao = true;
        }
    }

    else if(LinhaOrigem == 0 && ColunaOrigem == 1){
        if(LinhaDestino == 0 && ColunaDestino == 0 || LinhaDestino == 0 && ColunaDestino == 2 || LinhaDestino == 1 && ColunaDestino == 1){
            permissao = true;
        }
    }
    else if(LinhaOrigem == 0 && ColunaOrigem == 2){
        if(LinhaDestino == 0 && ColunaDestino == 1 || LinhaDestino == 5 && ColunaDestino == 2){
            permissao = true;
        }
    }

    //Linha 1

    else if(LinhaOrigem == 1 && ColunaOrigem == 0){
        if(LinhaDestino == 3 && ColunaDestino == 1 || LinhaDestino == 1 && ColunaDestino == 1){
            permissao = true;
        }
    }

    else if(LinhaOrigem == 1 && ColunaOrigem == 1){
        if(LinhaDestino == 1 && ColunaDestino == 0 || LinhaDestino == 2 && ColunaDestino == 1 || LinhaDestino == 1 && ColunaDestino == 2 ||  LinhaDestino == 0 && ColunaDestino == 1 ){
            permissao = true;
        }
    }
    else if(LinhaOrigem == 1 && ColunaOrigem == 2){
        if(LinhaDestino == 1 && ColunaDestino == 1 || LinhaDestino == 5 && ColunaDestino == 1){
            permissao = true;
        }
    }

    //Linha 2

    else if(LinhaOrigem == 2 && ColunaOrigem == 0){
        if(LinhaDestino == 3 && ColunaDestino == 2 || LinhaDestino == 2 && ColunaDestino == 1){
            permissao = true;
        }
    }

    else if(LinhaOrigem == 2 && ColunaOrigem == 1){
        if(LinhaDestino == 2 && ColunaDestino == 0 || LinhaDestino == 1 && ColunaDestino == 1 || LinhaDestino == 2 && ColunaDestino == 2){
            permissao = true;
        }
    }
    else if(LinhaOrigem == 2 && ColunaOrigem == 2){
        if(LinhaDestino == 2 && ColunaDestino == 1 || LinhaDestino == 5 && ColunaDestino == 0){
            permissao = true;
        }
    }

    //Linha 3

    else if(LinhaOrigem == 3 && ColunaOrigem == 0 ){
        if(LinhaDestino == 0 && ColunaDestino == 0 || LinhaDestino == 3 && ColunaDestino == 1 || LinhaDestino == 7 && ColunaDestino == 0){
            permissao = true;
        }
    }

    else if(LinhaOrigem == 3 && ColunaOrigem == 1){
        if(LinhaDestino == 3 && ColunaDestino == 0 || LinhaDestino == 1 && ColunaDestino == 0 || LinhaDestino == 6 && ColunaDestino == 0 || LinhaDestino == 3 && ColunaDestino == 2){
            permissao = true;
        }
    }
    else if(LinhaOrigem == 3 && ColunaOrigem == 2){
        if(LinhaDestino == 3 && ColunaDestino == 1 || LinhaDestino == 2 && ColunaDestino == 0 || LinhaDestino == 4 && ColunaDestino == 0){
            permissao = true;
        }
    }

    //Linha 4
    else if(LinhaOrigem == 4 && ColunaOrigem == 0){
        if(LinhaDestino == 3 && ColunaDestino == 2 || LinhaDestino == 4 && ColunaDestino == 1){
            permissao = true;
        }
    }

    else if(LinhaOrigem == 4 && ColunaOrigem == 1){
        if(LinhaDestino == 4 && ColunaDestino == 0 || LinhaDestino == 6 && ColunaDestino == 1 || LinhaDestino == 4 && ColunaDestino == 2){
            permissao = true;
        }
    }
    else if(LinhaOrigem == 4 && ColunaOrigem == 2){
        if(LinhaDestino == 4 && ColunaDestino == 1 || LinhaDestino == 5 && ColunaDestino == 0){
            permissao = true;
        }
    }

    //Linha 5

    else if(LinhaOrigem == 5 && ColunaOrigem == 0){
        if(LinhaDestino == 2 && ColunaDestino == 2 || LinhaDestino == 5 && ColunaDestino == 1 || LinhaDestino == 4 && ColunaDestino == 2){
            permissao = true;
        }
    }

    else if(LinhaOrigem == 5 && ColunaOrigem == 1){
        if(LinhaDestino == 5 && ColunaDestino == 0 || LinhaDestino == 1 && ColunaDestino == 2 || LinhaDestino == 6 && ColunaDestino == 2 || LinhaDestino == 5 && ColunaDestino == 2){
            permissao = true;
        }
    }
    else if(LinhaOrigem == 5 && ColunaOrigem == 2){
        if(LinhaDestino == 5 && ColunaDestino == 1 || LinhaDestino == 0 && ColunaDestino == 2 || LinhaDestino == 7 && ColunaDestino == 2 ){
            permissao = true;
        }
    }

    //Linha 6

    else if(LinhaOrigem == 6 && ColunaOrigem == 0){
        if(LinhaDestino == 3 && ColunaDestino == 1 || LinhaDestino == 6 && ColunaDestino == 1){
            permissao = true;
        }
    }

    else if(LinhaOrigem == 6 && ColunaOrigem == 1){
        if(LinhaDestino == 6 && ColunaDestino == 0 || LinhaDestino == 4 && ColunaDestino == 1 || LinhaDestino == 7 && ColunaDestino == 1 || LinhaDestino == 6 && ColunaDestino == 2){
            permissao = true;
        }
    }
    else if(LinhaOrigem == 6 && ColunaOrigem == 2){
        if(LinhaDestino == 5 && ColunaDestino == 1 || LinhaDestino == 6 && ColunaDestino == 1){
            permissao = true;
        }
    }

    //Linha 7

    else if(LinhaOrigem == 7 && ColunaOrigem == 0){
        if(LinhaDestino == 3 && ColunaDestino == 0 || LinhaDestino == 7 && ColunaDestino == 1){
            permissao = true;
        }
    }

    else if(LinhaOrigem == 7 && ColunaOrigem == 1){
        if(LinhaDestino == 7 && ColunaDestino == 0 || LinhaDestino == 6 && ColunaDestino == 1 || LinhaDestino == 7 && ColunaDestino == 2){
            permissao = true;
        }
    }
    else if(LinhaOrigem == 7 && ColunaOrigem == 2){
        if(LinhaDestino == 7 && ColunaDestino == 1 || LinhaDestino == 5 && ColunaDestino == 2){
            permissao = true;
        }
    }
    else{

    }
    return permissao;
 }

 void limparCin() {
    cin.clear(); // Limpa o estado de erro do cin
    cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Ignora o restante da linha
}
void Tela_liga(){
    system("cls");
    gotoxy(13, 3);
    printf("                                        ############");
    gotoxy(13, 4);
    printf("                                    ########  ..########");
    gotoxy(13, 5);
    printf("                                  ##########    ##########");
    gotoxy(13, 6);
    printf("                                ############    ############");
    gotoxy(13, 7);
    printf("                              ########    ##    ##    ########");
    gotoxy(13, 8);
    printf("                              ######      ##    ##      ######");
    gotoxy(13, 9);
    printf("                            ########    ####    ####    ########");
    gotoxy(13, 10);
    printf("                            ######    ######    ######    ######");
    gotoxy(13, 11);
    printf("                            ######    ######    ######    ######");
    gotoxy(13, 12);
    printf("                            ######    ######    ######    ######");
    gotoxy(13, 13);
    printf("                            ######    ################    ######");
    gotoxy(13, 14);
    printf("                            ######    ################  ::######");
    gotoxy(13, 15);
    printf("                              ######    ############    ######");
    gotoxy(13, 16);
    printf("                              ########      ####      ########");
    gotoxy(13, 17);
    printf("                                ########            ########");
    gotoxy(13, 18);
    printf("                                  ########################");
    gotoxy(13, 19);
    printf("                                    ####################");
    gotoxy(13, 20);
}

void animacao_tela_inicial_trilha(){
    gotoxy(10,1);printf("                                                    ");
    gotoxy(10,2);printf("                                                    ");
    gotoxy(10,3);printf("                                                    ");
    gotoxy(10,4);printf("                                                    ");
    for (int linha = 12; linha >= 1; linha--) {
        // Limpa a linha com um fundo LIGHTBLUE
        gotoxy(13, linha);
        // Move para a posi��o inicial da linha e imprime o texto com fundo branco e texto azul
        gotoxy(13, linha);
        textbackground(LIGHTBLUE);
        textcolor(WHITE);
        // Imprime a linha correspondente usando if
        if (linha == 5) {
            printf(" _________ _______ _________ _                 _______ ");
        } else if (linha == 6) {
            printf(" \\__   __/(  ____ )\\__   __/( \\      |\\     /|(  ___  )");
        } else if (linha == 7) {
            printf("    ) (   | (    )|   ) (   | (      | )   ( || (   ) |");
        } else if (linha == 8) {
            printf("    | |   | (____)|   | |   | |      | (___) || (___) |");
        } else if (linha == 9) {
            printf("    | |   |     __)   | |   | |      |  ___  ||  ___  |");
        } else if (linha == 10) {
            printf("    | |   | (\\ (      | |   | |      | (   ) || (   ) |");
        } else if (linha == 11) {
            printf("    | |   | ) \\ \\_____) (___| (____/\\| )   ( || )   ( |");
        } else if (linha == 12) {
            printf("    )_(   |/   \\__/\\_______/(_______/|/     \\||/     \\|");
        }
        // Atraso para visualizar a anima��o
        Sleep(100);  // Ajuste conforme necess�rio para a velocidade
    }
}

void exibir_carregamento() {
    for (int posicao = 50; posicao >= 1; posicao--) {
        gotoxy(1, 14);
        printf(" "); // Redefine o espa�o onde a anima��o vai ocorrer
        gotoxy(posicao, 14);
        textbackground(WHITE);
        textcolor(BLUE);
        printf("Bem-vindo ao jogo Trilha! ");
        Sleep(15); // Pausa entre os frames da anima��o
        textbackground(LIGHTBLUE); // Muda a cor de fundo ap�s a anima��o
        textcolor(WHITE); // Retorna � cor branca do texto
    }
    // Exibe o texto de "CARREGANDO" no centro da tela
    gotoxy(12, 15);
    printf("CARREGANDO ");
    textbackground(BLACK);
    printf(" ");
    gotoxy(23, 15);
    textbackground(GREEN); // Define o fundo verde para a anima��o final
    for (int i = 1; i <= 5; i++) {
        Sleep(300); // Pausa entre as partes da anima��o
        printf("."); // Exibe um ponto de carregamento
    }
    textbackground(LIGHTBLUE);
}

void menu_final(){
    gotoxy(1,1); printf("Jogo encerrado! Obrigado por ter jogado. ");
    gotoxy(1, 3);
    printf("Equipe desenvolvedora: Lagarto");
    gotoxy(1, 4); printf("Ana Souza");
    gotoxy(1, 5); printf("Bernardo Silva");
    gotoxy(1, 6); printf("David Silvino");
    gotoxy(1, 7); printf("Jose Lima");
    gotoxy(1, 8); printf("Kaua Lima");
    gotoxy(1, 9); printf("Luan Costa");
    gotoxy(1, 10); printf("Paulo Italo");
    gotoxy(1, 23); printf("Agradecimento ao nosso professor Dr. Alcides Xavier Benicasa");
    gotoxy(15, 5);
    printf("                                                    ....              \n");
    gotoxy(15, 6);
    printf("                                                ----++--::..          \n");
    gotoxy(15, 7);
    printf("                                              ..----++::::----        \n");
    gotoxy(15, 8);
    printf("                                              ------  ##  --------    \n");
    gotoxy(15, 9);
    printf("                                            --------..::  ------::    \n");
    gotoxy(15, 10);
    printf("                            ..--------..----------..::----------..    \n");
    gotoxy(15, 11);
    printf("                        ..------------------------                    \n");
    gotoxy(15, 12);
    printf("                      ----------------------------                    \n");
    gotoxy(15, 13);
    printf("                  ----------------------..----....                    \n");
    gotoxy(15, 14);
    printf("                ------------------------------..                      \n");
    gotoxy(15, 15);
    printf("              ----------....----..------  --..--                      \n");
    gotoxy(15, 16);
    printf("          ------------..    ------      ------                        \n");
    gotoxy(15, 17);
    printf("      ------------..      ..----        ..------------                \n");
    gotoxy(15, 18);
    printf("    --------            ------              ..------..                \n");
    gotoxy(15, 19);
    printf("                      --  --....              ----  ..                \n");
    gotoxy(15, 20);
    printf("                        --  --                  ..                    \n");
    gotoxy(15, 21);
    printf("                            --                                          \n");



}

void menu_final(bool& escolha_valida) {
    char opcao;
    escolha_valida = false;
    do {
        clrscr();
        tela_azul_fundo(LIGHTBLUE, WHITE, MAX_LINHAS);
        menu_final1();
        if(contPecaO <=2){
            gotoxy(29, 8); cout << "JOGADOR X GANHOU PARAB�NS";
        }
        else{
            gotoxy(29, 8); cout << "JOGADOR O GANHOU PARAB�NS";
        }
        gotoxy(35, 10); cout << "O que deseja fazer?";
        gotoxy(35, 12); cout << "1 - Jogar novamente";
        gotoxy(35, 14); cout << "2 - Sair do jogo";
        gotoxy(35, 16); cout << "Escolha uma op��o: ";
        cin >> opcao;

        switch(opcao) {
            case '1':
                escolha_valida = true;
                //reinicia o jogo
                break;
            case '2':
                clrscr();
                menu_final(); // Mostra tela de cr�ditos
                escolha_valida = false;
                exit(0);
                break;
            default:
                gotoxy(35, 18);
                cout << "Op��o inv�lida! Tente novamente.";
                Sleep(1500);
        }
    } while (!escolha_valida);
}


void menu_final1() {
        gotoxy(3, 5);printf(" _____________ \n");
        gotoxy(3, 6);printf("| _\"_________ |\n");
        gotoxy(3, 7);printf("||.---------.||\n");
        gotoxy(3, 8);printf("|||         |||\n");
        gotoxy(3, 9);printf("|||         |||\n");
        gotoxy(3, 10);printf("|||         |||\n");
        gotoxy(3, 11);printf("||'---------'/|\n");
        gotoxy(3, 12);printf("| \"\"\"\"\"\"\"\"` |\n");
        gotoxy(3, 13);printf("| ||  ^^^  () |\n");
        gotoxy(3, 14);printf("|[  ]    ()   |\n");
        gotoxy(3, 15);printf("| ||          |\n");
        gotoxy(3, 16);printf("|     _ _     |\n");
        gotoxy(3, 17);printf("|          :::|\n");
        gotoxy(3, 18);printf("|         .::'/\n");
        gotoxy(3, 19);printf("'\"\"\"\"\"\"\"\"\"\"\"` \n");

         gotoxy(65, 12);printf("     []  ,----.___   \n");
         gotoxy(65, 13);printf("   __||_/___      '. \n");
         gotoxy(65, 14);printf("  / O||    /|       )\n");
         gotoxy(65, 15);printf(" /   \"\"   / /   =._/ \n");
         gotoxy(65, 16);printf("/________/ /         \n");
         gotoxy(65, 17);printf("|________|/   dew     \n");


}

